## 1. Priekšnosacījumi

* Ir instalēta Java JDK 17+ un, ja izmantojat Maven, arī Maven 3+.
* Terminālis (Console) ar UTF-8 atbalstu.

---

## 2. Palaišana

1. Terminālī ejiet uz projekta sakni.
2. Izpildiet:

   ```bash
   mvn clean package
   java -jar target/pica-veikals.jar
   ```
3. Pēc brīža programma iztīrīs konsoli un attēlos galveno izvēlni.

---

## 3. Galvenā izvēlne

Pēc starta jūs redzēsiet krāsainu ASCII logotipu un izvēlni ar numuriem:

```
|| 1 – Picu saraksts
|| 2 – Pasūtīt picu
|| 3 – Akcijas
|| 4 – Ielogoties profilā / Iziet no profila
|| 5 – Sazināties ar mums
|| 6 – Pasūtījumu vēsture
|| 0 – Iziet
```

Vienkārši ievadiet vajadzīgo skaitli un nospiediet Enter.

---

## 4. Reģistrācija un pieteikšanās

1. **Izvēlieties “4” no galvenās izvēlnes.**
2. Parādīsies apakšizvēlne:

   ```
   1 – Ienākt lietotāja profilā
   2 – Ienākt administratora profilā
   3 – Izveidot jaunu profilu
   0 – Atgriezties
   ```
3. **Lai reģistrētos**, izvēlieties “3” → ievadiet lietotājvārdu, paroli, e-pastu → saņemsit apstiprinājumu “Profils veiksmīgi izveidots!”.
4. **Lai pieslēgtos**, izvēlieties “1” vai “2” → ievadiet lietotājvārdu un paroli → ja dati der, redzēsiet “Laipni lūdzam, <username>!”.
5. **Lai izrakstītos**, no galvenās izvēlnes vēlreiz izvēlieties “4” un programma paziņos “Jūs esat izrakstījies no profila”.

---

## 5. Picu saraksta pārlūkošana

1. Galvenajā izvēlnē ievadiet “1”.
2. Konsolē parādīsies tabula ar picu nosaukumiem un cenām 20 cm, 30 cm un 40 cm.
3. Zem tabulas — **filtrēšanas un kārtošanas izvēles**:

   ```
   1 – Filtrēt pēc 20 cm
   2 – Filtrēt pēc 30 cm
   3 – Filtrēt pēc 40 cm
   4 – Kārtot pēc cenas (lielākais → mazākais)
   5 – Kārtot pēc cenas (mazākais → lielākais)
   6 – Tikai gaļas picas
   7 – Tikai veģetārās picas
   … utt.
   0 – Atgriezties
   ```
4. Ievadiet attiecīgo skaitli, piemēram “4” — un saraksts tiks pārkārtots.
5. Lai apskatītu sastāvdaļas, vienkārši nepārbaudiet “13 – Picas bez sastāvdaļām”.

---

## 6. Pasūtīšanas process

1. Galvenajā izvēlnē ievadiet “2”.
2. Tiks izdrukāts picu saraksts ar numuriem.
3. **Izvēlieties picu** pēc tās numura (piemēram, “5”) → pēc tam **izmēru** (20, 30 vai 40) → un **daudzumu** (1–100).
4. Programmā jautās “Vai vēlaties pasūtīt vēl kādu picu? (jā/nē)”. Ievadiet “jā”, ja gribat turpināt, vai “nē” — ja pabeigt.
5. Programma lūgs **e-pastu** apstiprinājumam. Ievadiet adresi vai atstājiet tukšu, lai nerādītu e-pasta iespēju.
6. Jautājums par **promokodu**: ievadiet “jā” vai “nē”. Ja “jā”, ievadiet `atlaide10`, lai saņemtu 10 % atlaidi.
7. Izvēlieties **piegādes veidu**: “piegāde” (2.50 €) vai “pašizvešana” (bez maksas).
8. Programma otomātiski piemēros arī akcijas (kombo 1+2 ar 20% atlaidi, #4 30 cm ar 40% atlaidi, vairāk nekā 5 picas — piegāde bez maksas, divas 40 cm picas — 25% atlaide).
9. Tiks izdrukāts **pasūtījuma kopsavilkums** ar detalizētu cenu aprēķinu.
10. Ja e-pasts bija derīgs, tiks nosūtīts **e-pasta apstiprinājums** uz norādīto adresi.

---

## 7. Akcijas (vienkārša apskate)

1. Galvenajā izvēlnē ievadiet “3”.
2. Konsolē redzēsiet visu pieejamo akciju sarakstu:

   ```
   1 – Pica #1 + #2 (20 cm) ar 20% atlaidi
   2 – Pica #4 (30 cm) ar 40% atlaidi
   3 – >5 picu pasūtījums — piegāde bez maksas
   4 – 2×40 cm vienādas picas — 25% atlaide
   ```
3. Lai turpinātu, nospiediet Enter.

---

## 8. Atsauksmes un problēmas

1. Galvenajā izvēlnē ievadiet “5”.
2. Parādīsies apakšizvēlne:

   ```
   1 – Atstāt atsauksmi
   2 – Ziņot par problēmu
   (admins) 3 – Skatīt visas atsauksmes
   (admins) 4 – Skatīt visas problēmas
   0 – Atgriezties
   ```
3. **Atstājot atsauksmi**: izvēlieties “1” → ierakstiet tekstu → programmas paziņojums “Paldies par Jūsu atsauksmi!”.
4. **Ziņojot problēmu**: izvēlieties “2” → aprakstiet problēmu → redzēsiet “Problēma tika reģistrēta. Paldies!”.
5. Ja esat admins, varat izvēlēties “3” vai “4”, lai **apskatītu** visus ierakstus.

---

## 9. Pasūtījumu vēsture

1. Galvenajā izvēlnē ievadiet “6”.
2. **Lietotājiem** tiks rādīta tikai viņu pasūtījumu vēsture.
3. **Adminiem** tiks rādīti visi lietotāju pasūtījumi kopā.
4. Lai turpinātu, nospiediet Enter vai atgriezieties.

---

## 10. Iziešana

* No jebkuras galvenās izvēlnes izvēlieties “0” → programma izdrukās “Paldies, ka izmantojāt Pica veikalu!” un aizvērsies.

---

