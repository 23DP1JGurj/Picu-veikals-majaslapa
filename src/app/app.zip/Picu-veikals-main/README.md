# java-console
project template for Java CLI app

Saite uz programmas planu: https://pikcrvtlv-my.sharepoint.com/:x:/g/personal/a230245jg_rvt_lv/EXtW7CnOpBFIngqZugWSyEMBAKACwzKwlJCQs6nIYXsr8w?e=YahWyP