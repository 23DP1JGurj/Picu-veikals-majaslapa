package lv.rvt;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        PicaVeikalsApp app = new PicaVeikalsApp();
        app.start();
    }
}